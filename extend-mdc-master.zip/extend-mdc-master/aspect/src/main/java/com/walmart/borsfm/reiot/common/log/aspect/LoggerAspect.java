package com.walmart.borsfm.reiot.common.log.aspect;
import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import com.walmart.borsfm.reiot.common.log.annotation.Log;
@Aspect
public class LoggerAspect {
  private static final Logger LOGGER = Logger.getLogger(LoggerAspect.class.getName());
 
  @Around("@annotation(Log) && execution(@Log  * *.*(..))")
  public Object logTimeMethod(ProceedingJoinPoint joinPoint) throws Throwable{
    Object retVal = null;
    try {
      
      StringBuffer logMessage = new StringBuffer();
      logMessage.append(MDC.get("Controller"));
      logMessage.append(">>>");
      logMessage.append(MDC.get("ipavalue"));
      logMessage.append(">>>");
      logMessage.append(joinPoint.getTarget().getClass().getName());
      logMessage.append(".");
      logMessage.append(joinPoint.getSignature().getName());
      LOGGER.info("Execution Started for " + logMessage);      
      long start = System.currentTimeMillis();
      retVal = joinPoint.proceed();
      long elapsedTime = System.currentTimeMillis() - start;
      
      logMessage.append(" execution time: ");
      logMessage.append(elapsedTime);
      logMessage.append(" ms");      
      LOGGER.info("Execution Completed for " + logMessage);
    
    }catch(Throwable e) {      
      LOGGER.warn( "Method " + joinPoint.getSignature().getName() + " failed for the input '" + joinPoint.getArgs()[0] + "'. Original exception: " + e);
      throw e;
    }
    return retVal;
  }
 

 
}