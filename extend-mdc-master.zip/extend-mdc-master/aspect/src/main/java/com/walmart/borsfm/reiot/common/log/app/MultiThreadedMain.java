package com.walmart.borsfm.reiot.common.log.app;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import org.apache.log4j.BasicConfigurator;
import com.walmart.borsfm.reiot.common.log.annotation.*;


public class MultiThreadedMain extends Thread {



  
  public MultiThreadedMain() {

}
  

 
  
  
  @Log()
  @LogContext({ @MDCValue(value = "Controller", content = "Danfoss") })
  public void startBenchmark(int type) throws InterruptedException {
    System.out.println("Hi"+type);
    BlockingQueue<Integer> q1 = new ArrayBlockingQueue<Integer>(1);
    BlockingQueue<Integer> q2 = new ArrayBlockingQueue<Integer>(1);

    q2.offer(1);

    RackThread ping = new RackThread("PING", 30, q1, q2);
    RackThread pong = new RackThread("pong", 30, q2, q1);

    ping.initRack("192.168.1.1");
    pong.initRack("192.168.1.2");

    ping.join();
    pong.join();
  }
//  @Log()
  public static void main(String[] args) throws InterruptedException {
    BasicConfigurator.configure();
    MultiThreadedMain benchmark = new MultiThreadedMain();
    benchmark.startBenchmark(0);
  }

}