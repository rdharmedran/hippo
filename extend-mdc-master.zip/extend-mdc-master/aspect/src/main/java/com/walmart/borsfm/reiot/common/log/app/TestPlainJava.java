package com.walmart.borsfm.reiot.common.log.app;

import java.util.logging.Logger;
import com.walmart.borsfm.reiot.common.log.annotation.Log;
import com.walmart.borsfm.reiot.common.log.annotation.LogLevel;


public class TestPlainJava {
  private static final Logger LOGGER = Logger.getLogger("LoggerAspect");
  @Log()
private void hello() {
  System.out.println("hello");
  
}

  public static void main(String[] args) {
    
  System.out.println("hi");
  TestPlainJava java=new TestPlainJava();
  java.hello();
  }

}
