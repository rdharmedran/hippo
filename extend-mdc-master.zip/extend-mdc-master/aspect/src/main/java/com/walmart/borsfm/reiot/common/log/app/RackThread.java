package com.walmart.borsfm.reiot.common.log.app;

import java.util.Random;
import java.util.concurrent.BlockingQueue;
import com.walmart.borsfm.reiot.common.log.annotation.Log;
import com.walmart.borsfm.reiot.common.log.annotation.LogContext;
import com.walmart.borsfm.reiot.common.log.annotation.MDCValue;

public class RackThread  extends Thread {

  
  private String name;
  private int n;
  private BlockingQueue<Integer> serving;
  private BlockingQueue<Integer> receiving;
  private Random random = new Random();
  private  String ip;

 public  RackThread(){
  
  }
 
 public RackThread(String name,
     int n,
     BlockingQueue<Integer> serving,
     BlockingQueue<Integer> receiving) {
   
   this.name = name;
   this.n = n;
   this.serving = serving;
   this.receiving = receiving;
}

@LogContext()
@Log()
 public void initRack(@MDCValue("ipavalue") String ip) {
  System.out.println("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH");
   this.ip=ip;
   this.start();
  }
 
  @Override
  @Log()
  public void run() {
      for (int i = 0; i < n; ++i) {
          try {
              int k = receiving.take();
              System.out.println("[" + name + "]: got " + k);
              this.call(k);
              Thread.sleep(random.nextInt(1000));
              serving.put(k + 1);
          } catch (InterruptedException e) {
              break;
          }
      }
  }
  
 @Log()
  public void call(int type) {
    System.out.println("Hi"+type);
  }
  
}
