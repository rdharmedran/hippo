package com.walmart.borsfm.reiot.common.log.annotation;

public enum LogLevel {

  TRACE,
  DEBUG,
  INFO,
  WARN,
  ERROR,
  FATAL,
  NONE;
}