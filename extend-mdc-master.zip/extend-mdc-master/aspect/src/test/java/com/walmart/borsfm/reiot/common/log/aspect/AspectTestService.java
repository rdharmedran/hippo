package com.walmart.borsfm.reiot.common.log.aspect;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;
import org.apache.log4j.MDC;
import org.hamcrest.Matcher;
import com.walmart.borsfm.reiot.common.log.annotation.LogContext;
import com.walmart.borsfm.reiot.common.log.annotation.MDCValue;



public class AspectTestService {
  @LogContext({ @MDCValue(value = "TestValue1", content = "TestContent1"),
      @MDCValue(value = "TestValue2", content = "TestContent2"), @MDCValue("EmptyValue") })
  public void testAnnotationDefinedValues() {
    assertThat(MDC.get("TestValue1"), is(equalTo("TestContent1")));
    assertThat(MDC.get("TestValue2"), is(equalTo("TestContent2")));
    assertThat(MDC.get("EmptyValue"), is(equalTo("")));
  }

  @LogContext
  public void testMethodParameters(@MDCValue("ObjectValue") Object objectParam,
      @MDCValue("StringValue") String stringParam, @MDCValue("IntegerValue") Integer integerParam,
      @MDCValue("LongValue") Long longParam, @MDCValue("FloatValue") Float floatParam,
      @MDCValue("DoubleValue") Double doubleParam, @MDCValue("BooleanValue") Boolean booleanParam,
      String ignoredParam) {
    assertThat(MDC.get("ObjectValue"), is(equalTo(String.valueOf(objectParam))));
    assertThat(MDC.get("StringValue"), is(equalTo(stringParam)));
    assertThat(MDC.get("IntegerValue"), is(equalTo(String.valueOf(integerParam))));
    assertThat(MDC.get("LongValue"), is(equalTo(String.valueOf(longParam))));
    assertThat(MDC.get("FloatValue"), is(equalTo(String.valueOf(floatParam))));
    assertThat(MDC.get("DoubleValue"), is(equalTo(String.valueOf(doubleParam))));
    assertThat(MDC.get("BooleanValue"), is(equalTo(String.valueOf(booleanParam))));
  }

  private void assertThat(Object object, Matcher<String> matcher) {
    // TODO Auto-generated method stub
    
  }
}
