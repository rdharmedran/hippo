package com.walmart.borsfm.reiot.common.log.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.*;
import static org.junit.Assert.*;
import org.springframework.aop.ProxyMethodInvocation;
import org.springframework.aop.aspectj.MethodInvocationProceedingJoinPoint;

/**
 * The class <code>LoggerAspectTest</code> contains tests for the class <code>{@link LoggerAspect}</code>.
 *
 * @generatedBy CodePro at 7/15/18 3:07 AM
 * @author 180484
 * @version $Revision: 1.0 $
 */
public class LoggerAspectTest {
  /**
   * Run the LoggerAspect() constructor test.
   *
   * @generatedBy CodePro at 7/15/18 3:07 AM
   */
  @Test
  public void testLoggerAspect_1()
    throws Exception {
    LoggerAspect result = new LoggerAspect();
    assertNotNull(result);
    // add additional test code here
  }

  /**
   * Run the Object logTimeMethod(ProceedingJoinPoint) method test.
   *
   * @throws Throwable
   *
   * @generatedBy CodePro at 7/15/18 3:07 AM
   */
  @Test(expected = java.lang.IllegalArgumentException.class)
  public void testLogTimeMethod_1()
    throws Throwable {
    LoggerAspect fixture = new LoggerAspect();
    ProceedingJoinPoint joinPoint = new MethodInvocationProceedingJoinPoint((ProxyMethodInvocation) null);

    Object result = fixture.logTimeMethod(joinPoint);

    // add additional test code here
    assertNotNull(result);
  }

  /**
   * Perform pre-test initialization.
   *
   * @throws Exception
   *         if the initialization fails for some reason
   *
   * @generatedBy CodePro at 7/15/18 3:07 AM
   */
  @Before
  public void setUp()
    throws Exception {
    // add additional set up code here
  }

  /**
   * Perform post-test clean-up.
   *
   * @throws Exception
   *         if the clean-up fails for some reason
   *
   * @generatedBy CodePro at 7/15/18 3:07 AM
   */
  @After
  public void tearDown()
    throws Exception {
    // Add additional tear down code here
  }

  /**
   * Launch the test.
   *
   * @param args the command line arguments
   *
   * @generatedBy CodePro at 7/15/18 3:07 AM
   */
  public static void main(String[] args) {
    new org.junit.runner.JUnitCore().run(LoggerAspectTest.class);
  }
}