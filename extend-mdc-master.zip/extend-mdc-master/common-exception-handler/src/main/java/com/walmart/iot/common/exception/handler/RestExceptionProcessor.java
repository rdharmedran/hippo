/**
 * File : RestExceptionProcessor.java
 * 
 * @author: drajend3@ford.com
 * @created By:20 June 2016
 * @updated By: drajend3@ford.com
 * @updated On: Aug 31, 2017
 * 
 * 
 */
package com.ford.paak.paakfi.exception;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.config.ResourceNotFoundException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.util.WebUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.paak.paakfi.model.ResponseStatusEnum;
import com.netflix.hystrix.exception.HystrixBadRequestException;
import com.netflix.hystrix.exception.HystrixRuntimeException;

/**
 * The Class RestExceptionProcessor.
 */
@EnableWebMvc
@ControllerAdvice
@RestController
public class RestExceptionProcessor extends ResponseEntityExceptionHandler {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(RestExceptionProcessor.class);

	/**
	 * Consumer key exception.
	 *
	 * @param req
	 *            the req
	 * @param ex
	 *            the ex
	 * @return the response entity
	 * @throws JsonProcessingException
	 *             the json processing exception
	 */
	@ExceptionHandler(value = ConsumerKeyException.class)
	@ResponseBody
	public ResponseEntity<?> consumerKeyException(HttpServletRequest req, ConsumerKeyException ex)
			throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		String errorURL = req.getRequestURL().toString();
		ErrorInfo info = new ErrorInfo(errorURL, ex);
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		LOGGER.error(mapper.writeValueAsString(logMessage));
		String jsonInString = mapper.writeValueAsString(info);
		LOGGER.error(jsonInString);
		  try {
			return ResponseEntity.status(HttpStatus.valueOf(info.getErrorCode())).body(jsonInString);
		  }catch(IllegalArgumentException excep) {
		    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);
		  }
		}

	/**
	 * Handle resource not found exception.
	 *
	 * @return the response entity
	 * @throws JsonProcessingException
	 *             the json processing exception
	 */
	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ResponseEntity<String> handleResourceNotFoundException() throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		ErrorInfo info = new ErrorInfo("Requested Resource is 	Not Found.Please check the URL",
				HttpStatus.NOT_FOUND.value());
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		LOGGER.error(mapper.writeValueAsString(logMessage));
		String jsonInString = mapper.writeValueAsString(info);
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(jsonInString);
	}

	/**
	 * Handle method argument type mismatch.
	 *
	 * @param ex
	 *            the ex
	 * @param request
	 *            the request
	 * @return the response entity
	 * @throws JsonProcessingException
	 *             the json processing exception
	 */
	@ExceptionHandler({ MethodArgumentTypeMismatchException.class })
	public ResponseEntity<Object> handleMethodArgumentTypeMismatch(final MethodArgumentTypeMismatchException ex,
			final WebRequest request) throws JsonProcessingException {

		final String error = ex.getName() + " should be of type " + ex.getRequiredType().getName();
		ObjectMapper mapper = new ObjectMapper();
		ErrorInfo info = new ErrorInfo(error, HttpStatus.BAD_REQUEST.value());
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		LOGGER.error(mapper.writeValueAsString(logMessage));
		String jsonInString = mapper.writeValueAsString(info);
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);
	}

	/**
	 * Handle method argument type mismatch.
	 *
	 * @param ex
	 *            the ex
	 * @param request
	 *            the request
	 * @return the response entity
	 * @throws JsonProcessingException
	 *             the json processing exception
	 */
	@ExceptionHandler(HystrixBadRequestException.class)
	public ResponseEntity<Object> handleHystrixBadRequestException(HttpServletRequest req,
			HystrixBadRequestException ex) throws JsonProcessingException {

		final String error = ex.getMessage();
		ObjectMapper mapper = new ObjectMapper();
		ErrorInfo info = new ErrorInfo(error, HttpStatus.BAD_REQUEST.value());
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		LOGGER.error(mapper.writeValueAsString(logMessage));
		String jsonInString = mapper.writeValueAsString(info);
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);
	}

	@ExceptionHandler(HystrixRuntimeException.class)
	public ResponseEntity<Object> handleHystrixBadRequestException(HttpServletRequest req, HystrixRuntimeException ex)
			throws JsonProcessingException {

		final String error = ex.getMessage();
		ObjectMapper mapper = new ObjectMapper();
		ErrorInfo info = new ErrorInfo(error, HttpStatus.BAD_REQUEST.value());
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		LOGGER.error(mapper.writeValueAsString(logMessage));
		String jsonInString = mapper.writeValueAsString(info);
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);
	}

	/**
	 * Handle constraint violation.
	 *
	 * @param ex
	 *            the ex
	 * @param request
	 *            the request
	 * @return the response entity
	 * @throws JsonProcessingException
	 *             the json processing exception
	 */
	@ExceptionHandler({ ConstraintViolationException.class })
	public ResponseEntity<Object> handleConstraintViolation(final ConstraintViolationException ex,
			final WebRequest request) throws JsonProcessingException {

		final List<String> errors = new ArrayList<String>();
		for (final ConstraintViolation<?> violation : ex.getConstraintViolations()) {
			errors.add(violation.getRootBeanClass().getName() + " " + violation.getPropertyPath() + ": "
					+ violation.getMessage());
		}
		ObjectMapper mapper = new ObjectMapper();

		ErrorInfo info = new ErrorInfo("Constraint Violation Exception occured", HttpStatus.BAD_REQUEST.value());
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		LOGGER.error(mapper.writeValueAsString(logMessage));
		String jsonInString = mapper.writeValueAsString(info);
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);
	}

	/**
	 * Handle http request method not supported.
	 *
	 * @param ex
	 *            the ex
	 * @param headers
	 *            the headers
	 * @param status
	 *            the status
	 * @param request
	 *            the request
	 * @return the response entity
	 */
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
			final HttpRequestMethodNotSupportedException ex, final HttpHeaders headers, final HttpStatus status,
			final WebRequest request)  {

		final StringBuilder builder = new StringBuilder();
		builder.append(ex.getMethod());
		builder.append(" method is not supported for this request. Supported methods are ");
		ex.getSupportedHttpMethods().forEach(t -> builder.append(t + " "));
		ObjectMapper mapper = new ObjectMapper();
		ErrorInfo info = new ErrorInfo(builder.toString(), HttpStatus.BAD_REQUEST.value());
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		String jsonInString;
		try {
			LOGGER.error(mapper.writeValueAsString(logMessage));
			jsonInString = mapper.writeValueAsString(info);
		} catch (JsonProcessingException e) {
			jsonInString = " Method is not supported for this request.";
		}
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);
	}

	// 415

	/**
	 * Handle http media type not supported.
	 *
	 * @param ex
	 *            the ex
	 * @param headers
	 *            the headers
	 * @param status
	 *            the status
	 * @param request
	 *            the request
	 * @return the response entity
	 */
	protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(final HttpMediaTypeNotSupportedException ex,
			final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

		final StringBuilder builder = new StringBuilder();
		builder.append(ex.getContentType());
		builder.append("Media type is not supported. Supported media type(s) are: ");
		builder.append("application/json");
		ObjectMapper mapper = new ObjectMapper();
		ErrorInfo info = new ErrorInfo(builder.toString(), HttpStatus.BAD_REQUEST.value());
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		String jsonInString;
		try {
			LOGGER.error(mapper.writeValueAsString(logMessage));
			jsonInString = mapper.writeValueAsString(info);
		} catch (JsonProcessingException e) {
			jsonInString = " media type is not supported for this request.";
		}
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);
	}

	/*
	 * 
	 * /** Parser exception.
	 *
	 * @param req the req
	 * 
	 * @param ex the ex
	 * 
	 * @return the response entity
	 * 
	 * @throws JsonProcessingException the json processing exception
	 */
	/*
	 * @ExceptionHandler(value = HttpMessageNotReadableException.class)
	 * 
	 * @ResponseBody public ResponseEntity<String>
	 * parserException(HttpServletRequest req, HttpMessageNotReadableException
	 * ex) throws JsonProcessingException { ObjectMapper mapper = new
	 * ObjectMapper(); String errorURL = req.getRequestURL().toString();
	 * List<String> errorList = new ArrayList<String>();
	 * errorList.add(ex.getMostSpecificCause().toString()); ErrorInfo info = new
	 * ErrorInfo(new Date().getTime(), 400, ex.getLocalizedMessage(), errorURL,
	 * ex.getClass().getName(), errorList); String jsonInString =
	 * mapper.writeValueAsString(info); LOGGER.error(jsonInString); return
	 * ResponseEntity.status(400).body(jsonInString); }
	 * 
	 */

	@Override
	protected ResponseEntity<Object> handleBindException(final BindException ex, final HttpHeaders headers,
			final HttpStatus status, final WebRequest request) {

		ConsumerKeyException keyException = null;
		keyException = new ConsumerKeyException(ex);
		ObjectMapper mapper = new ObjectMapper();
		ErrorInfo info = new ErrorInfo("/", keyException);
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		String jsonInString;
		try {
			LOGGER.error(mapper.writeValueAsString(logMessage));
			jsonInString = mapper.writeValueAsString(info);
		} catch (JsonProcessingException e) {
			jsonInString = " Input is Not Valid";
		}
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);
	}

	// 404

	@Override
	protected ResponseEntity<Object> handleNoHandlerFoundException(final NoHandlerFoundException ex,
			final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

		final String error = "No handler found for " + ex.getHttpMethod() + " " + ex.getRequestURL();

		ObjectMapper mapper = new ObjectMapper();
		ErrorInfo info = new ErrorInfo(error, HttpStatus.NOT_FOUND.value());
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		String jsonInString;
		try {
			LOGGER.error(mapper.writeValueAsString(logMessage));
			jsonInString = mapper.writeValueAsString(info);
		} catch (JsonProcessingException e) {
			jsonInString = " Method is not supported for this request.";
		}
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(jsonInString);
	}


	/**
	 * A single place to customize the response body of all Exception types.
	 * <p>
	 * The default implementation sets the
	 * {@link WebUtils#ERROR_EXCEPTION_ATTRIBUTE} request attribute and creates
	 * a {@link ResponseEntity} from the given body, headers, and status.
	 * 
	 * @param ex
	 *            the exception
	 * @param body
	 *            the body for the response
	 * @param headers
	 *            the headers for the response
	 * @param status
	 *            the response status
	 * @param request
	 *            the current request
	 */
	@Override
	protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
			HttpStatus status, WebRequest request) {

		if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
			request.setAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, ex, WebRequest.SCOPE_REQUEST);
		}
		
		ConsumerKeyException keyException = null;
		keyException = new ConsumerKeyException(ex);
		ObjectMapper mapper = new ObjectMapper();
		String path = "/";
		if (request != null)
			path = request.getContextPath();
		ErrorInfo info =null;
		if(ex instanceof HttpMessageNotReadableException) {
		  info = new ErrorInfo(((HttpMessageNotReadableException) ex).getLocalizedMessage(), ResponseStatusEnum.INVALID_REQUEST.value());
		}else {
		  info = new ErrorInfo(path, keyException);
		}
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		String jsonInString;
		try {
			LOGGER.error(mapper.writeValueAsString(logMessage));
			jsonInString = mapper.writeValueAsString(info);
		} catch (JsonProcessingException e) {
			jsonInString = " Something went wrong";
		}
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);

	}

	@Override
	protected ResponseEntity<Object> handleServletRequestBindingException(ServletRequestBindingException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		ConsumerKeyException keyException = new ConsumerKeyException(ex.getMessage(), status);
		ObjectMapper mapper = new ObjectMapper();
		ErrorInfo info = new ErrorInfo("/", keyException);
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		String jsonInString;
		try {
			LOGGER.error(mapper.writeValueAsString(logMessage));
			jsonInString = mapper.writeValueAsString(info);
		} catch (JsonProcessingException e) {
			jsonInString = " Input is Not Valid";
		}
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);
	}

	/**
	 * Customize the response for NoHandlerFoundException.
	 * <p>
	 * This method delegates to {@link #handleExceptionInternal}.
	 * 
	 * @param ex
	 *            the exception
	 * @param headers
	 *            the headers to be written to the response
	 * @param status
	 *            the selected response status
	 * @param webRequest
	 *            the current request
	 * @return a {@code ResponseEntity} instance
	 */
	@Override
	protected ResponseEntity<Object> handleAsyncRequestTimeoutException(AsyncRequestTimeoutException ex,
			HttpHeaders headers, HttpStatus status, WebRequest webRequest) {

		if (webRequest instanceof ServletWebRequest) {
			ServletWebRequest servletRequest = (ServletWebRequest) webRequest;
			HttpServletRequest request = servletRequest.getNativeRequest(HttpServletRequest.class);
			HttpServletResponse response = servletRequest.getNativeResponse(HttpServletResponse.class);
			LOGGER.error(ex.toString());
			if (response.isCommitted()) {
				if (logger.isErrorEnabled()) {
					logger.error("Async timeout for " + request.getMethod() + " [" + request.getRequestURI() + "]");
				}
				return null;
			}
		}

		return handleExceptionInternal(ex, null, headers, status, webRequest);
	}

	/**
	 * Customize the response for NoSuchRequestHandlingMethodException.
	 * <p>
	 * This method logs a warning and delegates to
	 * {@link #handleExceptionInternal}.
	 * 
	 * @param ex
	 *            the exception
	 * @param headers
	 *            the headers to be written to the response
	 * @param status
	 *            the selected response status
	 * @param request
	 *            the current request
	 * @return a {@code ResponseEntity} instance
	 */
	@Override
	protected ResponseEntity<Object> handleNoSuchRequestHandlingMethod(
			org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		LOGGER.error(ex.toString());
		pageNotFoundLogger.warn(ex.getMessage());

		return handleExceptionInternal(ex, null, headers, status, request);
	}

	/**
	 * Handle all.
	 *
	 * @param ex
	 *            the ex
	 * @param request
	 *            the request
	 * @return the response entity
	 * @throws JsonProcessingException
	 *             the json processing exception
	 */
	@ExceptionHandler({ Throwable.class })
	public ResponseEntity<Object> handleAll(final Throwable ex, final WebRequest request)
			throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		ErrorInfo info = new ErrorInfo(ex.getMessage() != null ? ex.getMessage() : ex.getLocalizedMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR.value());
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		String jsonInString = mapper.writeValueAsString(info);
		LOGGER.error(mapper.writeValueAsString(logMessage));
		LOGGER.error(jsonInString);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jsonInString);

	}

	/**
	 * ConsumerKeyException processor
	 *
	 * @param req
	 *            the req
	 * @param ex
	 *            the ex
	 * @return the string
	 * @throws JsonProcessingException
	 */
	@ExceptionHandler(value = FeaturePackageException.class)
	@ResponseBody
	public ResponseEntity<String> featurePackageException(HttpServletRequest req, FeaturePackageException ex)
			throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		String errorURL = req.getRequestURL().toString();
		// ErrorInfo info = new ErrorInfo(new Date().getTime(),ex.getStatus(),
		// ex.getMsg(),errorURL,ex.getErrors());
		if (ex.getMsg() == null) {
			System.out.println(ex.getErrors());
			ex.setMsg(ex.getErrors().toString());
		}
		ErrorInfo info = new ErrorInfo(ex.getMsg(), Integer.parseInt(ex.getStatus()));
		String jsonInString = mapper.writeValueAsString(info);
		String replaceString = jsonInString.replace("status", "returnCode");
		jsonInString = replaceString.replace("message", "returnMessage");
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		LOGGER.error(mapper.writeValueAsString(logMessage));
		LOGGER.error(jsonInString);
		if (Integer.parseInt(ex.getStatus()) < 200) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST.value()).body(jsonInString);
		}
		return ResponseEntity.status(Integer.parseInt(ex.getStatus())).body(jsonInString);
	}

	/**
	 * UtilException processor
	 *
	 * @param req
	 *            the req
	 * @param ex
	 *            the ex
	 * @return the string
	 * @throws JsonProcessingException
	 */

	/*
	 * @ExceptionHandler(value = UtilException.class)
	 * 
	 * @ResponseBody public ResponseEntity<String>
	 * handleUtilException(HttpServletRequest req, UtilException ex) throws
	 * JsonProcessingException {
	 * 
	 * 
	 * 
	 * ObjectMapper mapper = new ObjectMapper(); String errorURL =
	 * req.getRequestURL().toString(); //ErrorInfo info = new ErrorInfo(new
	 * Date().getTime(),ex.getStatus(), ex.getMsg(),errorURL,ex.getErrors());
	 * //if(ex.getMessage() == null){ // System.out.println(ex.getErrors()); //
	 * ex.setMsg(ex.getErrors().toString()); //} ErrorInfo info = new
	 * ErrorInfo(ex.getMessage(),ex.getStatus()); String jsonInString =
	 * mapper.writeValueAsString(info); String
	 * replaceString=jsonInString.replace("status","returnCode");
	 * jsonInString=replaceString.replace("message","returnMessage");
	 * LOGGER.error(jsonInString); if(ex.getStatus() < 200) { return
	 * ResponseEntity.status(HttpStatus.BAD_REQUEST.value()).body(jsonInString);
	 * } return ResponseEntity.status(ex.getStatus()).body(jsonInString); }
	 */

	/**
	 * Consumer key exception.
	 *
	 * @param req
	 *            the req
	 * @param ex
	 *            the ex
	 * @return the response entity
	 * @throws JsonProcessingException
	 *             the json processing exception
	 */
	@ExceptionHandler(value = Exception.class)
	@ResponseBody
	public ResponseEntity<?> handleGeneralException(HttpServletRequest req, Exception ex)
			throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		String errorURL = req.getRequestURL().toString();
		ErrorInfo info = new ErrorInfo(errorURL, new ConsumerKeyException(ex));
		LogMessage logMessage=new LogMessage();
		logMessage.setBaseException(info.getException());
		logMessage.setReturnCode(info.getErrorCode());
		logMessage.setReturnMessage(info.getErrorMessage());
		String stackTrace=ExceptionUtils.getFullStackTrace(ex);
		logMessage.setStackTrace(stackTrace);
		LOGGER.error(mapper.writeValueAsString(logMessage));
		String jsonInString = mapper.writeValueAsString(info);
		LOGGER.error(jsonInString);
		if (info.getErrorCode() > 999 && info.getErrorCode() < 2000) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonInString);

		} else {
			return ResponseEntity.status(HttpStatus.valueOf(info.getErrorCode())).body(jsonInString);
		}

	}

}
