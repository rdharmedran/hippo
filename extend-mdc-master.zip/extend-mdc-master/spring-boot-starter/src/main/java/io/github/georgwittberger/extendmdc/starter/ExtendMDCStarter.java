package io.github.georgwittberger.extendmdc.starter;

/**
 * Dummy interface to facilitate attaching sources and Javadoc during Maven build.
 * 
 * @author Georg Wittberger
 */
public interface ExtendMDCStarter {
}
